tsc mainscript.ts
node mainscript.js